##Information

Le fichier TRACE.md contient le contenue d'un terminal lors du deroulement d'un partie avec l'interface graphique

## Reglages

Pour avoir la version terminal de l'aplication il suffit de prendre les codes en commentaires annoter Version terminale

Vous pouvez changer le nombre de case et de ligne mais le nombre de case doit etre impaire et le nombre de ligne doit correspondre
exemple : 
```java
    static final int N_CASES = 45;
    static final int N_LIGNES = 9;
```

## Lancement de l'application'

Il faut compiler les ficher Jeton.java et StdDraw.java

Pour compiler
```bash
javac *.java
```

Pour lancer l'application executer la commande :'

```bash
java Jeton
```
